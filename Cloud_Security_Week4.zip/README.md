
# Cloud Security Monitoring
## Emerging Electronics Store — Week 4

### 1. Project Scope
This project analyzes simulated AWS CloudTrail-style
events for a fictional electronics store to identify
potentially suspicious cloud activity.

### 2. Tools
- Google Colab
- Python
- pandas
- Simulated cloud event dataset

### 3. Detection Use Cases
Seven rules were created to flag:
1. Root account login
2. MFA disabled
3. New access key creation
4. Public storage policy changes
5. Activity from a selected unusual region
6. Console login failures
7. Policy creation

### 4. Testing
A separate three-event test dataset was used to
check whether detection rules flag selected events.
The results should be reviewed before deployment.

### 5. Limitations
The events are simulated, not real AWS CloudTrail
records. The rules are basic indicators and may
generate false positives. Production deployment
requires schema validation and additional testing.

### 6. Future Improvements
Use authentic public sample logs, improve detection
logic, test more normal and suspicious scenarios,
and validate results against AWS documentation.

### 7. Annual Cost Estimate
The lab used Google Colab and local notebook
downloads. No AWS services were provisioned.
Therefore, no AWS charges were incurred by this
exercise. Production cloud costs are not estimated
until log volume, retention, and service pricing
are defined.
